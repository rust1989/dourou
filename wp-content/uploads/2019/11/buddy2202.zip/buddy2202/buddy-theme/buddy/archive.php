<?php get_header(); ?>

<?php get_template_part( 'post', 'loop' ); ?>
					
<?php get_footer(); ?>