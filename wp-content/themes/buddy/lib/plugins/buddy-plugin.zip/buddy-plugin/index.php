<?php
/*
Plugin Name: Buddy Plugin
Plugin URI: http://themeforest.net/item/buddy-multipurpose-wordpress-buddypress-theme/3506362?ref=GhostPool
Description: A required plugin for the Buddy theme you purchased from ThemeForest. It includes a number of features that you can still use if you switch to another theme.
Version: 2.1.8
Author: GhostPool
Author URI: http://themeforest.net/user/GhostPool/portfolio?ref=GhostPool
License: You should have purchased a license from ThemeForest.net
Text Domain: buddy-plugin
*/

if ( ! class_exists( 'GhostPool_Buddy' ) ) {

	class GhostPool_Buddy {

		public function __construct() {
		
			// Load plugin translations
			add_action( 'plugins_loaded', array( &$this, 'ghostpool_plugin_load_textdomain' ) );
						
			// Add shortcode support to Text widget
			add_filter( 'widget_text', 'do_shortcode' );

			// Add excerpt support to pages
			if ( ! function_exists( 'ghostpool_add_excerpts_to_pages' ) ) {
				function ghostpool_add_excerpts_to_pages() {
					 add_post_type_support( 'page', 'excerpt' );
				}
			}
			add_action( 'init', 'ghostpool_add_excerpts_to_pages' );

			// Load shortcodes
			if ( ! class_exists( 'GhostPool_Shortcodes' ) ) {
				require_once( dirname( __FILE__ ) . '/shortcodes/theme-shortcodes.php' );
				$GhostPool_Shortcodes = new GhostPool_Shortcodes();
			}
			
			// Load custom sidebars
			if ( ! class_exists( 'GhostPool_Custom_Sidebars' ) ) {
				require_once( dirname( __FILE__ ) . '/custom-sidebars/custom-sidebars.php' );
			}
			
			// Load slide post type
			if ( ! post_type_exists( 'gp_slide' ) && ! class_exists( 'GhostPool_Slides' ) ) {
				require_once( dirname( __FILE__ ) . '/inc/slide-tax.php' );
				$GhostPool_Slides = new Ghostpool_Slides();
			}

			// One click demo installer
			require_once( dirname( __FILE__ ) . '/demo-installer/init.php' );				
							
		} 
		
		public static function ghostpool_activate() {} 		
		
		public static function ghostpool_deactivate() {}
		
		public function ghostpool_plugin_load_textdomain() {
			load_plugin_textdomain( 'buddy-plugin', false, trailingslashit( WP_LANG_DIR ) . 'plugins/' );
			load_plugin_textdomain( 'buddy-plugin', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
		}
				
	}
	
}

// WP mail function
if ( ! function_exists( 'ghostpool_wp_mail' ) ) {
	function ghostpool_wp_mail( $to = '', $subject = '', $message = '', $headers = '' ) {
		return wp_mail( $to, $subject, $message, $headers );				
	}
}

// User registration emails
if ( ! function_exists( 'wp_new_user_notification' ) && ! function_exists( 'bp_is_active' ) ) {
	function wp_new_user_notification( $user_id, $deprecated = null, $notify = 'both' ) {

		if ( $deprecated !== null ) {
			_deprecated_argument( __FUNCTION__, '4.3.1' );
		}
	
		global $wpdb;
		$user = get_userdata( $user_id );
		
		$user_login = stripslashes( $user->user_login );
		$user_email = stripslashes( $user->user_email );

		// The blogname option is escaped with esc_html on the way into the database in sanitize_option
		// we want to reverse this for the plain text arena of emails.
		$blogname = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
		
		// Admin email
		$message  = sprintf( esc_html__( 'New user registration on your blog %s:', 'buddy-plugin' ), $blogname ) . "\r\n\r\n";
		$message .= sprintf( esc_html__( 'Username: %s', 'buddy-plugin' ), $user_login ) . "\r\n\r\n";
		$message .= sprintf( esc_html__( 'Email: %s', 'buddy-plugin' ), $user_email ) . "\r\n";
		$message = apply_filters( 'ghostpool_registration_notice_message', $message, $blogname, $user_login, $user_email );
		@wp_mail( get_option( 'admin_email' ), sprintf( apply_filters( 'ghostpool_registration_notice_subject', esc_html__( '[%s] New User Registration', 'buddy-plugin' ), $blogname ), $blogname ), $message );

		if ( 'admin' === $notify || empty( $notify ) ) {
			return;
		}
		
		// User email
		$message  = esc_html__( 'Hi there,', 'buddy-plugin' ) . "\r\n\r\n";
		$message .= sprintf( esc_html__( 'Welcome to %s.', 'buddy-plugin' ), $blogname ) . "\r\n\r\n";
		$message .= sprintf( esc_html__( 'Username: %s', 'buddy-plugin' ), $user_login ) . "\r\n";
		$message .= esc_html__( 'Password: [use the password you entered when signing up]', 'buddy-plugin' ) . "\r\n\r\n";
		$message .= esc_html__( 'Please login at', 'buddy-plugin' ) . ' ' . get_option( 'buddy_login_url' ) . "\r\n\r\n";	
		$message = apply_filters( 'ghostpool_registered_user_message', $message, $blogname, $user_login, $user_email );
		wp_mail( $user_email, sprintf( apply_filters( 'ghostpool_registered_user_subject', esc_html__( '[%s] Your username and password', 'buddy-plugin' ), $blogname ), $blogname ), $message );

	}
	
}

// Active/deactivate plugin
if ( class_exists( 'GhostPool_Buddy' ) ) {

	register_activation_hook( __FILE__, array( 'GhostPool_Buddy', 'ghostpool_activate' ) );
	register_deactivation_hook( __FILE__, array( 'GhostPool_Buddy', 'ghostpool_deactivate' ) );

	$ghostpool_buddy = new GhostPool_Buddy();

}