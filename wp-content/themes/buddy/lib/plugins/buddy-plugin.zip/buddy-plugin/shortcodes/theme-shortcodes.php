<?php if ( ! class_exists( 'GhostPool_Shortcodes' ) ) {

	class GhostPool_Shortcodes {
	
		public function __construct() {
			add_action( 'init', array( &$this, 'ghostpool_shortcodes' ) );
		}
		
		public function ghostpool_shortcodes() {
		
			/*--------------------------------------------------------------
			If plugin is activated without theme
			--------------------------------------------------------------*/

			if ( ! function_exists( 'aq_resize' ) ) {
				function aq_resize() {}
			}
			if ( ! function_exists( 'ghostpool_excerpt' ) ) {	
				function ghostpool_excerpt() {}
			}
			if ( ! function_exists( 'ghostpool_pagination' ) ) {	
				function ghostpool_pagination() {}
			}
			if ( ! function_exists( 'ghostpool_title_limit' ) ) {	
				function ghostpool_title_limit() {}
			}
			if ( ! function_exists( 'ghostpool_pagination' ) ) {	
			 	function ghostpool_pagination() {}
			}
			

			/*--------------------------------------------------------------
			Shortcodes
			--------------------------------------------------------------*/
								
			// Accordions
			require_once( dirname( __FILE__ ) . '/accordions.php' );

			// Activity
			require_once( dirname( __FILE__ ) . '/activity-stream.php' );

			// Author Info
			require_once( dirname( __FILE__ ) . '/author-info.php' );

			// Blockquotes
			require_once( dirname( __FILE__ ) . '/blockquotes.php' );

			// Buttons
			require_once( dirname( __FILE__ ) . '/buttons.php' );

			// Columns
			require_once( dirname( __FILE__ ) . '/columns.php' );

			// Dividers
			require_once( dirname( __FILE__ ) . '/dividers.php' );

			// Dropcaps
			require_once( dirname( __FILE__ ) . '/dropcaps.php' );

			// Images
			require_once( dirname( __FILE__ ) . '/images.php' );

			// Lists
			require_once( dirname( __FILE__ ) . '/lists.php' );

			// Logged In
			require_once( dirname( __FILE__ ) . '/logged-in.php' );

			// Logged Out
			require_once( dirname( __FILE__ ) . '/logged-out.php' );

			// Login Form
			require_once( dirname( __FILE__ ) . '/login-form.php' );

			// Notifications
			require_once( dirname( __FILE__ ) . '/notifications.php' );

			// Posts
			require_once( dirname( __FILE__ ) . '/posts.php' );

			// Register Form
			require_once( dirname( __FILE__ ) . '/register-form.php' );

			// Related Posts
			require_once( dirname( __FILE__ ) . '/related-posts.php' );

			// Sidebars
			require_once( dirname( __FILE__ ) . '/sidebars.php' );

			// Slider
			require_once( dirname( __FILE__ ) . '/slider.php' );

			// Tabs
			require_once( dirname( __FILE__ ) . '/tabs.php' );

			// Text Boxes
			require_once( dirname( __FILE__ ) . '/text-boxes.php' );

			// Toggle Boxes
			require_once( dirname( __FILE__ ) . '/toggle-boxes.php' );

		}

	}

}
?>